package com.alura.latam.forum.domain.user;

public class UserActiveSesion {

    public static Long idUser;
    public static String username;
}
