package com.alura.latam.forum.domain.user;

public record DataAutenticationUser (String username, String password){
}
