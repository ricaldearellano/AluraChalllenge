package com.alura.latam.forum.infra.security;

public record DataJWTToken(String jwtToken) {
}
