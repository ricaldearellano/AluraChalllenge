package com.alura.latam.forum.domain.topic;

public enum StatusTopic {
    NO_RESPONDIDO,
    NO_SOLUCIONADO,
    SOLUCIONADO,
    CERRADO;
}
